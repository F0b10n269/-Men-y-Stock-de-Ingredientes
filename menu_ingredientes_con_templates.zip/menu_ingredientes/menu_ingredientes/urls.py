from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from mainApp.views import PlatoViewSet, IngredienteViewSet, StockViewSet
from mainApp import views  # para lista_platos y editar_plato

router = DefaultRouter()
router.register(r'platos', PlatoViewSet, basename='plato')
router.register(r'ingredientes', IngredienteViewSet, basename='ingrediente')
router.register(r'stock', StockViewSet, basename='stock')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.lista_platos, name='lista_platos'),
    path('editar/<int:id>/', views.editar_plato, name='editar_plato'),
    path('api/', include(router.urls)),  # <-- ESTO ES LO CORRECTO
]
