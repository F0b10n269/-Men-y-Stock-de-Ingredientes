# mainApp/views.py
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from django.db import transaction
from django.core.exceptions import ValidationError
from django.shortcuts import render, get_object_or_404, redirect  # <-- NUEVO: para la web
from .models import CategoriaMenu, Ingrediente, Plato, Receta, Stock, ReservaStock


# ================================================================
# SERIALIZERS (tu código original)
# ================================================================
class PlatoSerializer:
    def __init__(self, instance=None, data=None, partial=False):
        self.instance = instance
        self.data = data
        self.partial = partial

    def to_representation(self, instance):
        return {
            'id': instance.id,
            'nombre': instance.nombre,
            'descripcion': instance.descripcion,
            'precio': str(instance.precio),
            'categoria': {
                'id': instance.categoria.id if instance.categoria else None,
                'nombre': instance.categoria.nombre if instance.categoria else None
            },
            'activo': instance.activo,
            'recetas': [
                {
                    'id': receta.id,
                    'ingrediente': receta.ingrediente.nombre,
                    'unidad_medida': receta.ingrediente.unidad_medida,
                    'cantidad': str(receta.cantidad)
                } for receta in instance.recetas.all()
            ]
        }

    def is_valid(self):
        if not self.data:
            return False
        if not self.partial:
            required_fields = ['nombre', 'precio', 'categoria']
            for field in required_fields:
                if field not in self.data or not self.data[field]:
                    return False
        if 'precio' in self.data:
            try:
                precio = float(self.data['precio'])
                if precio <= 0:
                    return False
            except (TypeError, ValueError):
                return False
        if 'categoria' in self.data:
            try:
                CategoriaMenu.objects.get(id=self.data['categoria'])
            except CategoriaMenu.DoesNotExist:
                return False
        return True

    def save(self):
        if self.instance:
            if 'nombre' in self.data:
                self.instance.nombre = self.data['nombre']
            if 'descripcion' in self.data:
                self.instance.descripcion = self.data.get('descripcion', '')
            if 'precio' in self.data:
                self.instance.precio = self.data['precio']
            if 'categoria' in self.data:
                self.instance.categoria_id = self.data['categoria']
            self.instance.save()

            if 'recetas' in self.data:
                self.instance.recetas.all().delete()
                for receta_data in self.data.get('recetas', []):
                    ingrediente_id = receta_data.get('ingrediente_id')
                    cantidad = receta_data.get('cantidad')
                    if ingrediente_id and cantidad:
                        try:
                            ingrediente = Ingrediente.objects.get(id=ingrediente_id)
                            Receta.objects.create(plato=self.instance, ingrediente=ingrediente, cantidad=cantidad)
                        except Ingrediente.DoesNotExist:
                            pass
            return self.instance
        else:
            plato = Plato.objects.create(
                nombre=self.data['nombre'],
                descripcion=self.data.get('descripcion', ''),
                precio=self.data['precio'],
                categoria_id=self.data['categoria']
            )
            for receta_data in self.data.get('recetas', []):
                ingrediente_id = receta_data.get('ingrediente_id')
                cantidad = receta_data.get('cantidad')
                if ingrediente_id and cantidad:
                    try:
                        ingrediente = Ingrediente.objects.get(id=ingrediente_id)
                        Receta.objects.create(plato=plato, ingrediente=ingrediente, cantidad=cantidad)
                    except Ingrediente.DoesNotExist:
                        pass
            return plato


class IngredienteSerializer:
    def to_representation(self, instance):
        return {
            'id': instance.id,
            'nombre': instance.nombre,
            'unidad_medida': instance.unidad_medida,
            'stock_minimo': instance.stock_minimo
        }


class StockSerializer:
    def to_representation(self, instance):
        return {
            'id': instance.id,
            'ingrediente': instance.ingrediente.nombre,
            'cantidad_disponible': str(instance.cantidad_disponible)
        }


# ================================================================
# SERVICIO DE STOCK (tu código original)
# ================================================================
class StockService:
    @transaction.atomic
    def validar_y_reservar_stock(self, plato_id, cantidad, pedido_id):
        try:
            plato = Plato.objects.get(id=plato_id, activo=True)
            for receta in plato.recetas.all():
                stock = Stock.objects.get(ingrediente=receta.ingrediente)
                cantidad_necesaria = receta.cantidad * cantidad
                if stock.cantidad_disponible < cantidad_necesaria:
                    raise ValidationError(f"Stock insuficiente de {receta.ingrediente.nombre}. Necesario: {cantidad_necesaria}, Disponible: {stock.cantidad_disponible}")
            reserva = ReservaStock.objects.create(plato=plato, cantidad=cantidad, pedido_id=pedido_id, estado='reservado')
            for receta in plato.recetas.all():
                stock = Stock.objects.get(ingrediente=receta.ingrediente)
                cantidad_necesaria = receta.cantidad * cantidad
                stock.cantidad_disponible -= cantidad_necesaria
                stock.save()
            return reserva
        except Plato.DoesNotExist:
            raise ValidationError("Plato no encontrado o inactivo")
        except Stock.DoesNotExist:
            raise ValidationError("Error en configuración de stock")


# ================================================================
# VIEWSETS API (tu código original completo)
# ================================================================
class PlatoViewSet(viewsets.ViewSet):
    def list(self, request):
        platos = Plato.objects.filter(activo=True).select_related('categoria')
        serializer = PlatoSerializer()
        data = [serializer.to_representation(plato) for plato in platos]
        return Response(data)

    def retrieve(self, request, pk=None):
        try:
            plato = Plato.objects.get(pk=pk, activo=True)
            serializer = PlatoSerializer()
            return Response(serializer.to_representation(plato))
        except Plato.DoesNotExist:
            return Response({'error': 'Plato no encontrado'}, status=status.HTTP_404_NOT_FOUND)

    def create(self, request):
        serializer = PlatoSerializer(data=request.data)
        if serializer.is_valid():
            plato = serializer.save()
            return Response({'id': plato.id, 'message': 'Plato creado exitosamente'}, status=status.HTTP_201_CREATED)
        return Response({'error': 'Datos inválidos'}, status=status.HTTP_400_BAD_REQUEST)

    def update(self, request, pk=None):
        try:
            plato = Plato.objects.get(pk=pk, activo=True)
        except Plato.DoesNotExist:
            return Response({'error': 'Plato no encontrado'}, status=status.HTTP_404_NOT_FOUND)
        serializer = PlatoSerializer(instance=plato, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Plato actualizado exitosamente'})
        return Response({'error': 'Datos inválidos'}, status=status.HTTP_400_BAD_REQUEST)

    def partial_update(self, request, pk=None):
        try:
            plato = Plato.objects.get(pk=pk, activo=True)
        except Plato.DoesNotExist:
            return Response({'error': 'Plato no encontrado'}, status=status.HTTP_404_NOT_FOUND)
        serializer = PlatoSerializer(instance=plato, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Plato actualizado parcialmente'})
        return Response({'error': 'Datos inválidos'}, status=status.HTTP_400_BAD_REQUEST)

    def destroy(self, request, pk=None):
        try:
            plato = Plato.objects.get(pk=pk)
            plato.activo = False
            plato.save()
            return Response({'message': 'Plato desactivado exitosamente'})
        except Plato.DoesNotExist:
            return Response({'error': 'Plato no encontrado'}, status=status.HTTP_404_NOT_FOUND)


class IngredienteViewSet(viewsets.ViewSet):
    def list(self, request):
        ingredientes = Ingrediente.objects.all()
        serializer = IngredienteSerializer()
        data = [serializer.to_representation(ing) for ing in ingredientes]
        return Response(data)


class StockViewSet(viewsets.ViewSet):
    def list(self, request):
        stocks = Stock.objects.all()
        serializer = StockSerializer()
        data = [serializer.to_representation(stock) for stock in stocks]
        return Response(data)

    @action(detail=False, methods=['post'])
    def validar_reservar(self, request):
        plato_id = request.data.get('plato_id')
        cantidad = request.data.get('cantidad')
        pedido_id = request.data.get('pedido_id')
        if not plato_id or not cantidad or not pedido_id:
            return Response({'error': 'Faltan datos'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            cantidad = int(cantidad)
            if cantidad <= 0:
                return Response({'error': 'cantidad debe ser mayor a 0'}, status=status.HTTP_400_BAD_REQUEST)
        except (TypeError, ValueError):
            return Response({'error': 'cantidad inválida'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            stock_service = StockService()
            reserva = stock_service.validar_y_reservar_stock(plato_id, cantidad, pedido_id)
            return Response({'success': True, 'reserva_id': reserva.id, 'message': 'Stock reservado'})
        except ValidationError as e:
            return Response({'success': False, 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)


# ================================================================
# VISTAS WEB (las que te faltaban para que funcione la página)
# ================================================================
def lista_platos(request):
    platos = Plato.objects.filter(activo=True)
    return render(request, 'lista_platos.html', {'lista_platos': platos})

def editar_plato(request, id):
    plato = get_object_or_404(Plato, id=id, activo=True)
    
    if request.method == 'POST':
        plato.nombre = request.POST['nombre']
        plato.descripcion = request.POST['descripcion']
        plato.precio = request.POST['precio']
        plato.save()
        return redirect('lista_platos')
    
    return render(request, 'editar_plato.html', {'plato': plato})